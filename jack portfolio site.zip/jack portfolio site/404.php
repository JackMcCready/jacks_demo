<?php get_header(); ?>
	<p>Error 404<br />Sorry the page you are looking for doesn't exsist.</p>
<?php get_footer(); ?>