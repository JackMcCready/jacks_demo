<?php
add_action('init','jquery_register');

function jquery_register() {
    if(!is_admin()) {
      wp_deregister_script('jquery');
      wp_register_script('jquery',('https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js'),false,null,true);
      wp_enqueue_script('jquery');
    }
}

if(!defined('WP_POST_REVISIONS')) define('WP_POST_REVISIONS',10);

function remove_default_userfields( $contactmethods ) {
  unset($contactmethods['aim']);
  unset($contactmethods['jabber']);
  unset($contactmethods['yim']);
  return $contactmethods;
}
add_filter('user_contactmethods','remove_default_userfields', 10,1);