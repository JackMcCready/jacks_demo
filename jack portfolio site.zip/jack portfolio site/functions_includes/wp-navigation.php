<?php
/* 
  USAGE 
  wp_nav_menu( array('menu' => 'Main Menu') );
*/
function register_navigation() {
  register_nav_menus(
    array(
      'main-menu'   => __( 'Main Menu' ),
      'footer-menu' => __( 'Footer Menu' )
    )
  );
}
add_action( 'init', 'register_navigation' );